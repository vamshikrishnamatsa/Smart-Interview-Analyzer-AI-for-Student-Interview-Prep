# record_audio.py

import sounddevice as sd
import soundfile as sf
import numpy as np
import tempfile

samplerate = 16000
channels = 1

# Start/stop logic with session-state-friendly variable
recording_data = []  # Will be reset at start

def start_recording():
    global recording_data
    recording_data = []  # Reset recording
    def callback(indata, frames, time, status):
        if status:
            print(status)
        recording_data.append(indata.copy())

    # Attach to stream object and store in global
    sd.recorder_stream = sd.InputStream(
        samplerate=samplerate, channels=channels, callback=callback
    )
    sd.recorder_stream.start()

def stop_recording():
    global recording_data
    if hasattr(sd, 'recorder_stream'):
        sd.recorder_stream.stop()
        sd.recorder_stream.close()

    # Combine all chunks
    audio_np = np.concatenate(recording_data, axis=0)

    # Save to temp .wav
    temp_wav = tempfile.NamedTemporaryFile(delete=False, suffix=".wav")
    sf.write(temp_wav.name, audio_np, samplerate)
    return temp_wav.name
