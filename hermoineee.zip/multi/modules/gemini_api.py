import google.generativeai as genai
import os
from dotenv import load_dotenv

load_dotenv()

# Correct way: load the API key from your environment (.env file)
genai.configure(api_key=os.getenv("AIzaSyCjxdgf-ioqlY04pJSkoZFSz66DHuGD6KU"))


# Load Gemini 1.5 Flash model
model = genai.GenerativeModel("gemini-1.5-flash")

def get_response(prompt):
    try:
        response = model.generate_content(prompt)
        return response.text
    except Exception as e:
        return f"Error generating response: {str(e)}"
